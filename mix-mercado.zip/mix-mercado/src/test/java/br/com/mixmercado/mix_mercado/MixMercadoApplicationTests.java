package br.com.mixmercado.mix_mercado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MixMercadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
